#!/usr/bin/env python2
# -*- encoding=utf-8 -*-

# description:
# author:jack
# create_time: 2018/5/26

"""
    desc:pass
"""

from dueros.directive.Display.template.TextImageTemplate import TextImageTemplate


class BodyTemplate4(TextImageTemplate):

    def __init__(self):
        super(BodyTemplate4, self).__init__('BodyTemplate4')


if __name__ == '__main__':
    pass